package com.aryan.ecom.repository;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.*;

class CategoryRepositoryTest {
    // No custom method

    @BeforeEach
    void setUp() {

    }

    @AfterEach
    void tearDown() {
    }
}