package com.aryan.ecom.enums;

public enum OrderStatus {
	Pending,
	Placed,
	Shipped,
	Delivered
}
